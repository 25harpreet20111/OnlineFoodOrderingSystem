/* ==================================================================
   PRODUCT DATA
================================================================== */
const products = [
  // ---------- FRUITS & VEGETABLES ----------
  {id:1, name:"Fresh Shimla Apples", category:"fruits-veg", brand:"Farm Fresh", veg:true, price:180, mrp:220, unit:"1 kg", img:"https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400&q=80", desc:"Crisp and juicy Shimla apples, handpicked and rich in fiber & vitamins.", featured:true},
  {id:2, name:"Robusta Bananas", category:"fruits-veg", brand:"Farm Fresh", veg:true, price:50, mrp:60, unit:"12 pcs", img:"https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400&q=80", desc:"Naturally ripened bananas — a perfect energy-packed snack.", featured:true},
  {id:3, name:"Juicy Oranges", category:"fruits-veg", brand:"Farm Fresh", veg:true, price:120, mrp:140, unit:"1 kg", img:"https://images.unsplash.com/photo-1547514701-42782101795e?w=400&q=80", desc:"Sweet and tangy oranges, loaded with Vitamin C.", featured:true},
  {id:4, name:"Fresh Tomatoes", category:"fruits-veg", brand:"Farm Fresh", veg:true, price:40, mrp:50, unit:"1 kg", img:"https://images.unsplash.com/photo-1546094096-0df4bcaaa337?w=400&q=80", desc:"Farm-fresh red tomatoes, perfect for curries and salads.", featured:false},
  {id:5, name:"Red Onions", category:"fruits-veg", brand:"Farm Fresh", veg:true, price:35, mrp:45, unit:"1 kg", img:"https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&q=80", desc:"Farm-fresh onions, an everyday kitchen essential.", featured:false},
  {id:6, name:"Potatoes", category:"fruits-veg", brand:"Farm Fresh", veg:true, price:30, mrp:38, unit:"1 kg", img:"https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400&q=80", desc:"Fresh, farm-grown potatoes ideal for all your recipes.", featured:false},

  // ---------- DAIRY PRODUCTS ----------
  {id:7, name:"Amul Toned Milk", category:"dairy", brand:"Amul", veg:true, price:66, mrp:70, unit:"1 L", img:"https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400&q=80", desc:"Fresh toned milk, pasteurized and packed with nutrition.", featured:true},
  {id:8, name:"Amul Butter", category:"dairy", brand:"Amul", veg:true, price:250, mrp:270, unit:"500 g", img:"https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=400&q=80", desc:"Creamy, delicious butter made from fresh cream.", featured:false},
  {id:9, name:"Fresh Curd", category:"dairy", brand:"Nestle", veg:true, price:45, mrp:52, unit:"400 g", img:"https://images.unsplash.com/photo-1571212515416-fca988083b48?w=400&q=80", desc:"Thick and creamy curd, great for meals and digestion.", featured:false},
  {id:10, name:"Cheese Slices", category:"dairy", brand:"Britannia", veg:true, price:120, mrp:135, unit:"200 g", img:"https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?w=400&q=80", desc:"Delicious processed cheese slices for sandwiches & burgers.", featured:false},

  // ---------- SNACKS ----------
  {id:11, name:"Lay's Classic Chips", category:"snacks", brand:"Lay's", veg:true, price:20, mrp:25, unit:"52 g", img:"https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=400&q=80", desc:"Crispy salted potato chips — a favourite anytime snack.", featured:true},
  {id:12, name:"Good Day Cookies", category:"snacks", brand:"Britannia", veg:true, price:35, mrp:40, unit:"250 g", img:"https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=400&q=80", desc:"Butter cookies with a rich, crunchy taste.", featured:false},
  {id:13, name:"Bikaneri Namkeen Mix", category:"snacks", brand:"Haldiram's", veg:true, price:60, mrp:70, unit:"200 g", img:"https://images.unsplash.com/photo-1621939514649-280e2ee25f60?w=400&q=80", desc:"Spicy and crunchy traditional Indian namkeen mix.", featured:false},
  {id:14, name:"Dairy Milk Chocolate", category:"snacks", brand:"Cadbury", veg:true, price:40, mrp:45, unit:"55 g", img:"https://images.unsplash.com/photo-1511381939415-e44015466834?w=400&q=80", desc:"Smooth, creamy milk chocolate bar.", featured:true},
  {id:15, name:"Chicken Nuggets (Frozen)", category:"snacks", brand:"Godrej Yummiez", veg:false, price:180, mrp:210, unit:"300 g", img:"https://images.unsplash.com/photo-1562967914-608f82629710?w=400&q=80", desc:"Ready-to-fry crispy chicken nuggets.", featured:false},

  // ---------- BEVERAGES ----------
  {id:16, name:"Coca-Cola", category:"beverages", brand:"Coca-Cola", veg:true, price:45, mrp:50, unit:"750 ml", img:"https://images.unsplash.com/photo-1543253687-c931c8e01820?w=400&q=80", desc:"Chilled, refreshing cola drink.", featured:false},
  {id:17, name:"Real Fruit Juice", category:"beverages", brand:"Real", veg:true, price:110, mrp:125, unit:"1 L", img:"https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400&q=80", desc:"Mixed fruit juice made from real fruit pulp.", featured:true},
  {id:18, name:"Tata Tea Gold", category:"beverages", brand:"Tata", veg:true, price:140, mrp:150, unit:"250 g", img:"https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=400&q=80", desc:"Rich, aromatic tea leaves for the perfect cup.", featured:false},
  {id:19, name:"Bisleri Water Bottle", category:"beverages", brand:"Bisleri", veg:true, price:20, mrp:20, unit:"1 L", img:"https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400&q=80", desc:"Pure and safe packaged drinking water.", featured:false},

  // ---------- HOUSEHOLD ITEMS ----------
  {id:20, name:"Surf Excel Detergent", category:"household", brand:"Surf Excel", veg:true, price:150, mrp:170, unit:"1 kg", img:"https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&q=80", desc:"Powerful detergent powder that removes tough stains.", featured:false},
  {id:21, name:"Vim Dishwash Liquid", category:"household", brand:"Vim", veg:true, price:99, mrp:110, unit:"500 ml", img:"https://images.unsplash.com/photo-1563453392212-326f5e854473?w=400&q=80", desc:"Removes grease easily, leaving dishes sparkling clean.", featured:false},
  {id:22, name:"Tissue Paper Rolls", category:"household", brand:"Origin Fresh", veg:true, price:60, mrp:70, unit:"Pack of 2", img:"https://images.unsplash.com/photo-1584556812952-905ffd0c611a?w=400&q=80", desc:"Soft and strong tissue rolls for everyday use.", featured:false},
];

/* ==================================================================
   STATE
================================================================== */
let cart = [];   // {id, qty}
let filters = { veg:"all", maxPrice:300, categories:[], brands:[] };
let currentModalProductId = null;

const categoryMeta = {
  "fruits-veg": {title:"Fruits & Vegetables", container:"fruitsvegContainer"},
  "dairy": {title:"Dairy Products", container:"dairyContainer"},
  "snacks": {title:"Snacks", container:"snacksContainer"},
  "beverages": {title:"Beverages", container:"beveragesContainer"},
  "household": {title:"Household Items", container:"householdContainer"},
};

/* ==================================================================
   RENDER PRODUCT CARD
================================================================== */
function productCardHTML(p){
  const discount = Math.round(((p.mrp - p.price)/p.mrp)*100);
  return `
  <div class="col-6 col-md-4 col-lg-3">
    <div class="product-card position-relative p-2">
      ${discount>0 ? `<span class="discount-tag">${discount}% OFF</span>` : ""}
      <div class="product-img-wrap rounded-3" onclick="openProductModal(${p.id})">
        <img src="${p.img}" alt="${p.name}" loading="lazy">
      </div>
      <div class="p-2">
        <div class="d-flex align-items-center mb-1">
          <span class="veg-dot ${p.veg? "" : "nonveg"}"></span>
          <span class="product-unit">${p.unit}</span>
        </div>
        <div class="product-title" onclick="openProductModal(${p.id})">${p.name}</div>
        <div class="mt-2 d-flex justify-content-between align-items-center">
          <div>
            <span class="fw-bold" style="color:var(--purple-dark);">₹${p.price}</span>
            ${p.mrp>p.price ? `<span class="price-mrp">₹${p.mrp}</span>` : ""}
          </div>
          <button class="btn-add" onclick="quickAdd(${p.id})">ADD</button>
        </div>
      </div>
    </div>
  </div>`;
}

function passesFilter(p){
  if(filters.veg==="veg" && !p.veg) return false;
  if(filters.veg==="nonveg" && p.veg) return false;
  if(p.price > filters.maxPrice) return false;
  if(filters.categories.length && !filters.categories.includes(p.category)) return false;
  if(filters.brands.length && !filters.brands.includes(p.brand)) return false;
  return true;
}

function renderAll(){
  // Featured
  const featured = products.filter(p=>p.featured && passesFilter(p));
  document.getElementById("featuredContainer").innerHTML = featured.length
    ? featured.map(productCardHTML).join("")
    : `<p class="empty-msg">No featured products match the selected filters.</p>`;

  // Category sections
  Object.keys(categoryMeta).forEach(cat=>{
    const list = products.filter(p=>p.category===cat && passesFilter(p));
    const el = document.getElementById(categoryMeta[cat].container);
    el.innerHTML = list.length
      ? list.map(productCardHTML).join("")
      : `<p class="empty-msg">No products found in this category for the selected filters.</p>`;
  });
}

/* ==================================================================
   FILTERS PANEL (built dynamically, shared for desktop + mobile)
================================================================== */
function buildFilterPanel(){
  const brands = [...new Set(products.map(p=>p.brand))].sort();
  const categoriesList = Object.keys(categoryMeta);

  const html = `
    <h6>Vegetarian / Non-Veg</h6>
    <div class="form-check">
      <input class="form-check-input" type="radio" name="vegFilter" id="vegAll" value="all" checked onchange="onVegChange(this.value)">
      <label class="form-check-label" for="vegAll">All</label>
    </div>
    <div class="form-check">
      <input class="form-check-input" type="radio" name="vegFilter" id="vegOnly" value="veg" onchange="onVegChange(this.value)">
      <label class="form-check-label" for="vegOnly"><span class="veg-dot"></span> Vegetarian</label>
    </div>
    <div class="form-check">
      <input class="form-check-input" type="radio" name="vegFilter" id="vegNon" value="nonveg" onchange="onVegChange(this.value)">
      <label class="form-check-label" for="vegNon"><span class="veg-dot nonveg"></span> Non-Vegetarian</label>
    </div>

    <h6>Price Range</h6>
    <input type="range" class="form-range" min="20" max="300" step="10" value="300" id="priceRange" oninput="onPriceChange(this.value)">
    <div class="small text-muted">Up to ₹<span id="priceRangeVal">300</span></div>

    <h6>Category</h6>
    ${categoriesList.map(cat=>`
      <div class="form-check">
        <input class="form-check-input cat-filter" type="checkbox" value="${cat}" id="cat-${cat}" onchange="onCheckboxFilterChange()">
        <label class="form-check-label" for="cat-${cat}">${categoryMeta[cat].title}</label>
      </div>`).join("")}

    <h6>Brand</h6>
    ${brands.map(b=>`
      <div class="form-check">
        <input class="form-check-input brand-filter" type="checkbox" value="${b}" id="brand-${b.replace(/[^a-zA-Z0-9]/g,'')}" onchange="onCheckboxFilterChange()">
        <label class="form-check-label" for="brand-${b.replace(/[^a-zA-Z0-9]/g,'')}">${b}</label>
      </div>`).join("")}

    <button class="btn btn-sm mt-3 w-100" style="background:var(--purple-light);color:var(--purple-dark);font-weight:600;border:none;" onclick="resetFilters()">Clear All Filters</button>
  `;
  document.getElementById("filterBoxDesktop").innerHTML = html;
  document.getElementById("filterBoxMobile").innerHTML = html;
}

function onVegChange(val){
  filters.veg = val;
  syncFilterInputs();
  renderAll();
}
function onPriceChange(val){
  filters.maxPrice = Number(val);
  document.querySelectorAll("#priceRangeVal").forEach(function(){});
  document.querySelectorAll('[id="priceRangeVal"]').forEach(el=>el.textContent=val);
  syncFilterInputs();
  renderAll();
}
function onCheckboxFilterChange(){
  filters.categories = Array.from(document.querySelectorAll(".cat-filter:checked")).map(el=>el.value);
  filters.brands = Array.from(document.querySelectorAll(".brand-filter:checked")).map(el=>el.value);
  // since two copies of panel exist (desktop/mobile), merge unique states from whichever was interacted with
  renderAll();
}
function syncFilterInputs(){
  document.querySelectorAll('input[name="vegFilter"]').forEach(el=>{ el.checked = (el.value===filters.veg); });
  document.querySelectorAll("#priceRange").forEach(el=>{ el.value = filters.maxPrice; });
}
function resetFilters(){
  filters = {veg:"all", maxPrice:300, categories:[], brands:[]};
  buildFilterPanel();
  syncFilterInputs();
  document.querySelectorAll('[id="priceRangeVal"]').forEach(el=>el.textContent="300");
  renderAll();
}

/* ==================================================================
   SEARCH
================================================================== */
function searchProducts(e){
  e.preventDefault();
  const term = document.getElementById("searchInput").value.trim().toLowerCase();
  if(!term){ renderAll(); return false; }
  const results = products.filter(p=> p.name.toLowerCase().includes(term) || p.brand.toLowerCase().includes(term));

  document.getElementById("featuredContainer").innerHTML = `<h5 class="text-muted mb-3">Search results for "${term}"</h5>`;
  Object.keys(categoryMeta).forEach(cat=> document.getElementById(categoryMeta[cat].container).innerHTML = "");

  const target = document.getElementById("featuredContainer");
  target.innerHTML += results.length ? results.map(productCardHTML).join("") : `<p class="empty-msg">No groceries found matching "${term}".</p>`;
  return false;
}

/* ==================================================================
   PRODUCT MODAL
================================================================== */
function openProductModal(id){
  const p = products.find(x=>x.id===id);
  if(!p) return;
  currentModalProductId = id;
  document.getElementById("modalImg").src = p.img;
  document.getElementById("modalTitle").textContent = p.name;
  document.getElementById("modalUnit").textContent = p.unit + " • " + p.brand;
  document.getElementById("modalPrice").textContent = p.price;
  document.getElementById("modalMrp").textContent = p.mrp;
  document.getElementById("modalDesc").textContent = p.desc;
  document.getElementById("modalQty").value = 1;
  document.getElementById("modalVegBadge").innerHTML =
    `<span class="veg-dot ${p.veg?"":"nonveg"}"></span><span class="small fw-semibold">${p.veg?"Vegetarian":"Non-Vegetarian"}</span>`;
  document.getElementById("modalAddBtn").onclick = function(){
    const qty = Number(document.getElementById("modalQty").value);
    addToCart(id, qty);
    bootstrap.Modal.getInstance(document.getElementById("productModal")).hide();
  };
  new bootstrap.Modal(document.getElementById("productModal")).show();
}
function changeModalQty(delta){
  const input = document.getElementById("modalQty");
  let val = Number(input.value) + delta;
  if(val < 1) val = 1;
  input.value = val;
}

/* ==================================================================
   CART
================================================================== */
function quickAdd(id){ addToCart(id, 1); }

function addToCart(id, qty){
  const existing = cart.find(c=>c.id===id);
  if(existing){ existing.qty += qty; }
  else{ cart.push({id, qty}); }
  renderCart();
}
function removeFromCart(id){
  cart = cart.filter(c=>c.id!==id);
  renderCart();
}
function changeCartQty(id, delta){
  const item = cart.find(c=>c.id===id);
  if(!item) return;
  item.qty += delta;
  if(item.qty<=0){ removeFromCart(id); return; }
  renderCart();
}

function renderCart(){
  const container = document.getElementById("cartItemsContainer");
  if(cart.length===0){
    container.innerHTML = `<p class="empty-msg text-center"><i class="bi bi-cart-x fs-1 d-block mb-2"></i>Your cart is empty.</p>`;
  } else {
    container.innerHTML = cart.map(c=>{
      const p = products.find(x=>x.id===c.id);
      return `
      <div class="cart-item">
        <img src="${p.img}" alt="${p.name}">
        <div class="flex-grow-1">
          <div class="d-flex justify-content-between">
            <span class="fw-semibold small">${p.name}</span>
            <i class="bi bi-trash text-danger" style="cursor:pointer;" onclick="removeFromCart(${p.id})"></i>
          </div>
          <div class="small text-muted">${p.unit}</div>
          <div class="d-flex justify-content-between align-items-center mt-1">
            <div class="d-flex align-items-center gap-2">
              <button class="cart-qty-btn" onclick="changeCartQty(${p.id},-1)">−</button>
              <span>${c.qty}</span>
              <button class="cart-qty-btn" onclick="changeCartQty(${p.id},1)">+</button>
            </div>
            <span class="fw-bold" style="color:var(--purple-dark);">₹${p.price * c.qty}</span>
          </div>
        </div>
      </div>`;
    }).join("");
  }

  const subtotal = cart.reduce((sum,c)=>{
    const p = products.find(x=>x.id===c.id);
    return sum + (p.price * c.qty);
  },0);
  const delivery = subtotal>0 && subtotal<199 ? 25 : 0;

  document.getElementById("cartSubtotal").textContent = "₹"+subtotal;
  document.getElementById("cartDelivery").textContent = "₹"+delivery;
  document.getElementById("cartTotal").textContent = "₹"+(subtotal+delivery);

  const totalItems = cart.reduce((s,c)=>s+c.qty,0);
  document.getElementById("cartBadge").textContent = totalItems;
}

/* ==================================================================
   INIT
================================================================== */
buildFilterPanel();
renderAll();
renderCart();
